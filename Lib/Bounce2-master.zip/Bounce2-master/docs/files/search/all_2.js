var searchData=
[
  ['changed',['changed',['../class_debouncer.html#a47c83f13a03920d21fbfafd8469ec06b',1,'Debouncer']]]
];
